const apiKey = 'e2e679f2254fddd35eff4b7d5b9e1089';
let unit = 'metric';  

// Поиск погоды по названию города
async function searchWeather() {
    const city = document.getElementById('cityInput').value;
    if (!city) return;
    await getWeatherData(city);
}

// Получение данных погоды и прогноза
async function getWeatherData(city) {
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=${unit}&appid=${apiKey}`);
    const data = await response.json();
    displayWeather(data);
    getForecast(city);
}

// Отображение текущей погоды
function displayWeather(data) {
    const weatherContainer = document.getElementById('weatherContainer');
    weatherContainer.innerHTML = `
        <h2>${data.name}, ${data.sys.country}</h2>
        <h3>${Math.round(data.main.temp)}° ${unit === 'metric' ? 'C' : 'F'}</h3>
        <p>${data.weather[0].description}</p>
        <p>Влажность: ${data.main.humidity}%</p>
        <p>Скорость ветра: ${data.wind.speed} ${unit === 'metric' ? 'м/с' : 'мили/ч'}</p>
        <button onclick="addToFavorites('${data.name}')">Добавить в избранное</button>
    `;
}

// Получение 5-дневного прогноза
async function getForecast(city) {
    const response = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=${unit}&appid=${apiKey}`);
    const data = await response.json();
    const forecastContainer = document.getElementById('forecastContainer');
    forecastContainer.innerHTML = '<h3>5-дневный прогноз:</h3>';

    for (let i = 0; i < data.list.length; i += 8) {
        const day = data.list[i];
        const forecastDay = document.createElement('div');
        forecastDay.className = 'forecast-day';
        forecastDay.innerHTML = `
            <h3>${new Date(day.dt_txt).toLocaleDateString()}</h3>
            <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}.png" alt="${day.weather[0].description}">
            <p>${Math.round(day.main.temp_max)}° / ${Math.round(day.main.temp_min)}°</p>
            <p>${day.weather[0].description}</p>
        `;
        forecastContainer.appendChild(forecastDay);
    }
}

// Добавление в избранное
function addToFavorites(city) {
    let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    if (!favorites.includes(city)) {
        favorites.push(city);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        updateFavorites();
    }
}

// Отображение избранных городов
function updateFavorites() {
    const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    const favoritesContainer = document.getElementById('favoriteCities');
    favoritesContainer.innerHTML = '';

    favorites.forEach(city => {
        const favoriteCity = document.createElement('div');
        favoriteCity.className = 'favorite-city';
        favoriteCity.innerHTML = `
            <h3>${city}</h3>
            <button onclick="getWeatherData('${city}')">Показать погоду</button>
            <button onclick="removeFromFavorites('${city}')">Удалить</button>
        `;
        favoritesContainer.appendChild(favoriteCity);
    });
}

// Удаление из избранного
function removeFromFavorites(city) {
    let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    favorites = favorites.filter(item => item !== city);
    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavorites();
}

// Определение текущего местоположения
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=${unit}&appid=${apiKey}`);
            const data = await response.json();
            displayWeather(data);
            getForecast(data.name);
        });
    }
}

// Переключение единиц измерения
function updateUnit() {
    unit = document.getElementById('unitToggle').value;
    const city = document.getElementById('cityInput').value;
    if (city) searchWeather();
}

window.onload = updateFavorites;
