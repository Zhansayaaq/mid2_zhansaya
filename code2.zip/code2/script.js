const apiKey = '20c9da956dcf36bb90113e7ebe9ebfb9';  
// Поиск фильмов
async function searchMovies() {
    const query = document.getElementById('searchInput').value;
    const sortBy = document.getElementById('sortBy').value;
    const response = await fetch(`https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${query}&sort_by=${sortBy}`);
    const data = await response.json();
    displayMovies(data.results);
}

// Отображение списка фильмов
function displayMovies(movies) {
    const moviesContainer = document.getElementById('moviesContainer');
    moviesContainer.innerHTML = '';

    movies.forEach(movie => {
        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';

        movieCard.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w500/${movie.poster_path}" alt="${movie.title}">
            <h3>${movie.title}</h3>
            <button onclick="showMovieDetails(${movie.id})">Подробнее</button>
            <button onclick="addToWatchlist(${movie.id})">Добавить в список</button>
        `;

        moviesContainer.appendChild(movieCard);
    });
}

// Отображение деталей фильма
async function showMovieDetails(id) {
    const response = await fetch(`https://api.themoviedb.org/3/movie/${id}?api_key=${apiKey}`);
    const movie = await response.json();

    const modalContent = `
        <h2>${movie.title}</h2>
        <p>${movie.overview}</p>
        <h3>Рейтинг: ${movie.vote_average}</h3>
        <h3>Длительность: ${movie.runtime} минут</h3>
    `;
    openModal(modalContent);
}

// Функция добавления в Watchlist с использованием Local Storage
function addToWatchlist(id) {
    let watchlist = JSON.parse(localStorage.getItem('watchlist')) || [];
    if (!watchlist.includes(id)) {
        watchlist.push(id);
        localStorage.setItem('watchlist', JSON.stringify(watchlist));
        updateWatchlist();
    }
}

// Обновление списка "Watchlist"
async function updateWatchlist() {
    const watchlist = JSON.parse(localStorage.getItem('watchlist')) || [];
    const watchlistContainer = document.getElementById('watchlistMovies');
    watchlistContainer.innerHTML = '';

    for (const id of watchlist) {
        const response = await fetch(`https://api.themoviedb.org/3/movie/${id}?api_key=${apiKey}`);
        const movie = await response.json();

        const movieCard = document.createElement('div');
        movieCard.className = 'movie-card';
        movieCard.innerHTML = `
            <img src="https://image.tmdb.org/t/p/w500/${movie.poster_path}" alt="${movie.title}">
            <h3>${movie.title}</h3>
            <button onclick="removeFromWatchlist(${movie.id})">Удалить</button>
        `;
        watchlistContainer.appendChild(movieCard);
    }
}

// Удаление из Watchlist
function removeFromWatchlist(id) {
    let watchlist = JSON.parse(localStorage.getItem('watchlist')) || [];
    watchlist = watchlist.filter(movieId => movieId !== id);
    localStorage.setItem('watchlist', JSON.stringify(watchlist));
    updateWatchlist();
}

window.onload = updateWatchlist;
